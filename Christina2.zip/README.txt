/* 
 *  Christina Taggart
 *  Program 4: Simple World Scene: Stonehenge
 *  CSC 471 with Professor Zoe Wood
 *  Description: Exploration of world through camera transforms
 *  in forwards, backwards, and side to side directions relative to current gaze
 *  as well as view rotation using the mouse
 *  Objects in world comprised of hierarchical models
 *  glut/OpenGL/GLSL application   
 *  Uses glm and local matrix stack
 *  to handle matrix transforms for a view matrix, projection matrix and
 *  model transform matrix
 *  Base Code provided by Zoe Wood
 *
 *****************************************************************************************************/

 To Compile: make
 To Run: ./a.out

 Keyboard Inputs: effects view/camera transform
  'a' - moves to the left of current gaze
  'd' - moves to the right of current gaze
  'w' - moves forward in the scene along the current gaze
  's' - moves backward in the scene along the current gaze
 'q' - quit the program

Because I modeled Stonehenge, I did not disperse my hierarchical rock models throughout the world,
but rather, closer together to be truer to the arrangement of Stonehenge as it appears today. I also 
used three hierarchical models instead of two: the arc appears ten times (large and small), the stacked 
stones three times, and the two little rocks on the ground seven times, to fulfill the assignment 
requirements. I also chose 3 material amounts for a few of the rock formations, but I kept them all 
near 0.5 because I thought it looked better overall. 