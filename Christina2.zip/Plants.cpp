/* Plants
 *
 */


#include "Models.h"

void DrawFlower1(){

	CurrentMesh = 25;
    safe_glEnableVertexAttribArray(h_aPosition);
    safe_glEnableVertexAttribArray(h_aNormal); 

    //main ellipse
    ModelTrans.pushMatrix();

      //ModelTrans.rotate(45, vec3(0, 1, 0)); 
      ModelTrans.translate(vec3(5, 10, 0));
      SetModel();
      safe_glEnableVertexAttribArray(h_aPosition);
      glBindBuffer(GL_ARRAY_BUFFER, Meshes[CurrentMesh]->PositionHandle);
      safe_glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
      safe_glEnableVertexAttribArray(h_aNormal);
      glBindBuffer(GL_ARRAY_BUFFER, Meshes[CurrentMesh]->NormalHandle);
      safe_glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, Meshes[CurrentMesh]->IndexHandle);
      glUniform3f(h_uColor, 0.0, 0.0, 0.0);
      safe_glUniform1f(h_uMaterial, 0.5);
      glDrawElements(GL_TRIANGLES, Meshes[CurrentMesh]->IndexBufferLength, GL_UNSIGNED_SHORT, 0);


    ModelTrans.popMatrix();
    safe_glDisableVertexAttribArray(h_aPosition);  
    safe_glDisableVertexAttribArray(h_aNormal);

}